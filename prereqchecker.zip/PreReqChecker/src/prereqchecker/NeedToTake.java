package prereqchecker;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;


/**
 * Steps to implement this class main method:
 * 
 * Step 1:
 * AdjListInputFile name is passed through the command line as args[0]
 * Read from AdjListInputFile with the format:
 * 1. a (int): number of courses in the graph
 * 2. a lines, each with 1 course ID
 * 3. b (int): number of edges in the graph
 * 4. b lines, each with a source ID
 * 
 * Step 2:
 * NeedToTakeInputFile name is passed through the command line as args[1]
 * Read from NeedToTakeInputFile with the format:
 * 1. One line, containing a course ID
 * 2. c (int): Number of courses
 * 3. c lines, each with one course ID
 * 
 * Step 3:
 * NeedToTakeOutputFile name is passed through the command line as args[2]
 * Output to NeedToTakeOutputFile with the format:
 * 1. Some number of lines, each with one course ID
 */



 public class NeedToTake {
     public static void main(String[] args) {
         if (args.length < 3) {
             System.out.println("Execute: java NeedToTake <adjacency list INput file> <need to take INput file> <need to take OUTput file>");
             return;
         }
         String adjListFile = args[0];
         String needToTakeFile = args[1];
         String outputFile = args[2];
 
         Map<String, Set<String>> graph = new HashMap<>();
         String targetCourse = null;
         Set<String> takenCourses = new HashSet<>();
 

         try (BufferedReader reader = new BufferedReader(new FileReader(adjListFile))) {
             int numCourses = Integer.parseInt(reader.readLine().trim());
             for (int i = 0; i < numCourses; i++) {
                 graph.put(reader.readLine().trim(), new HashSet<>());
             }
             int numEdges = Integer.parseInt(reader.readLine().trim());
             for (int i = 0; i < numEdges; i++) {
                 String[] edge = reader.readLine().trim().split(" ");
                 graph.get(edge[0]).add(edge[1]);
             }
         } catch (IOException e) {
             System.out.println("Error reading adjacency list file: " + e.getMessage());
             return;
         }
 
         // Read need to take input
         try (BufferedReader reader = new BufferedReader(new FileReader(needToTakeFile))) {
             targetCourse = reader.readLine().trim();
             int numTaken = Integer.parseInt(reader.readLine().trim());
             for (int i = 0; i < numTaken; i++) {
                 takenCourses.add(reader.readLine().trim());
             }
         } catch (IOException e) {
             System.out.println("Error reading need to take input file: " + e.getMessage());
             return;
         }
 
         Set<String> neededCourses = findNeededCourses(targetCourse, graph, takenCourses);
 
         try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {
             for (String course : neededCourses) {
                 writer.write(course);
                 writer.newLine();
             }
         } catch (IOException e) {
             System.out.println("Error writing output file: " + e.getMessage());
         }
     }
 
     private static Set<String> findNeededCourses(String targetCourse, Map<String, Set<String>> graph, Set<String> initialTakenCourses) {
         Set<String> effectivelyTaken = new HashSet<>(initialTakenCourses);
         for (String course : initialTakenCourses) {
             dfsMarkTaken(course, graph, effectivelyTaken);
         }
 
         Set<String> neededCourses = new HashSet<>();
         dfsNeedToTake(targetCourse, graph, effectivelyTaken, neededCourses);
         neededCourses.remove(targetCourse);
 
         return neededCourses;
     }
 
     private static void dfsMarkTaken(String course, Map<String, Set<String>> graph, Set<String> effectivelyTaken) {
         effectivelyTaken.add(course);
         for (String prereq : graph.get(course)) {
             if (!effectivelyTaken.contains(prereq)) {
                 dfsMarkTaken(prereq, graph, effectivelyTaken);
             }
         }
     }
 
     private static void dfsNeedToTake(String course, Map<String, Set<String>> graph, Set<String> effectivelyTaken, Set<String> neededCourses) {
         if (effectivelyTaken.contains(course)) {
             return;
         }
         neededCourses.add(course);
         for (String prereq : graph.get(course)) {
             dfsNeedToTake(prereq, graph, effectivelyTaken, neededCourses);
         }
     }
 }