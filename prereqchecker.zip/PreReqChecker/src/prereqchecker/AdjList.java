package prereqchecker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Steps to implement this class main method:
 * 
 * Step 1:
 * AdjListInputFile name is passed through the command line as args[0]
 * Read from AdjListInputFile with the format:
 * 1. a (int): number of courses in the graph
 * 2. a lines, each with 1 course ID
 * 3. b (int): number of edges in the graph
 * 4. b lines, each with a source ID
 * 
 * Step 2:
 * AdjListOutputFile name is passed through the command line as args[1]
 * Output to AdjListOutputFile with the format:
 * 1. c lines, each starting with a different course ID, then 
 *    listing all of that course's prerequisites (space separated)
 */
public class AdjList {
    public static void main(String[] args) {

        if ( args.length < 2 ) {
            StdOut.println("Execute: java -cp bin prereqchecker.AdjList <adjacency list INput file> <adjacency list OUTput file>");
            return;
        }

        String inputFile = args[0];
        String outputFile = args[1];

        StdIn.setFile(inputFile);
        StdOut.setFile(outputFile);

        int numCourses = StdIn.readInt();
        StdIn.readLine(); 

        Map<String, List<String>> adjList = new HashMap<>();

        List<String> courses = new ArrayList<>();
        for (int i = 0; i < numCourses; i++) {
            String course = StdIn.readLine().trim();
            courses.add(course);
            adjList.put(course, new ArrayList<>());
        }

        int numEdges = StdIn.readInt();
        StdIn.readLine(); 

        for (int i = 0; i < numEdges; i++) {
            String[] edge = StdIn.readLine().split(" ");
            String course = edge[0];
            String prereq = edge[1];
            adjList.get(course).add(prereq);
        }

        for (String course : courses) {
            StdOut.print(course);
            for (String prereq : adjList.get(course)) {
                StdOut.print(" " + prereq);
            }
            StdOut.println();
        
        }

    }
}
