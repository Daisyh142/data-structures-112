package prereqchecker;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;


/**
 * Steps to implement this class main method:
 * 
 * Step 1:
 * AdjListInputFile name is passed through the command line as args[0]
 * Read from AdjListInputFile with the format:
 * 1. a (int): number of courses in the graph
 * 2. a lines, each with 1 course ID
 * 3. b (int): number of edges in the graph
 * 4. b lines, each with a source ID
 * 
 * Step 2:
 * ValidPreReqInputFile name is passed through the command line as args[1]
 * Read from ValidPreReqInputFile with the format:
 * 1. 1 line containing the proposed advanced course
 * 2. 1 line containing the proposed prereq to the advanced course
 * 
 * Step 3:
 * ValidPreReqOutputFile name is passed through the command line as args[2]
 * Output to ValidPreReqOutputFile with the format:
 * 1. 1 line, containing either the word "YES" or "NO"
 */
public class ValidPrereq {
    public static void main(String[] args) {

        if ( args.length < 3 ) {
            StdOut.println("Execute: java -cp bin prereqchecker.ValidPrereq <adjacency list INput file> <valid prereq INput file> <valid prereq OUTput file>");
            return;
        }
        String adjListFile = args[0];
        String prereqFile = args[1];
        String outputFile = args[2];

        Map<String, List<String>> adjList = new HashMap<>();
        try {
            BufferedReader adjReader = new BufferedReader(new FileReader(adjListFile));
            int numCourses = Integer.parseInt(adjReader.readLine().trim());

            for (int i = 0; i < numCourses; i++) {
                String course = adjReader.readLine().trim();
                adjList.put(course, new ArrayList<>());
            }

            int numEdges = Integer.parseInt(adjReader.readLine().trim());
            for (int i = 0; i < numEdges; i++) {
                String[] edge = adjReader.readLine().trim().split(" ");
                String course = edge[0];
                String prereq = edge[1];
                adjList.get(course).add(prereq);
            }
            adjReader.close();
        } catch (IOException e) {
            System.out.println("Error reading adjacency list file: " + e.getMessage());
            return;
        }

        String course1 = null;
        String course2 = null;
        try {
            BufferedReader prereqReader = new BufferedReader(new FileReader(prereqFile));
            course1 = prereqReader.readLine().trim();
            course2 = prereqReader.readLine().trim();
            prereqReader.close();
        } catch (IOException e) {
            System.out.println("Error reading prereq file: " + e.getMessage());
            return;
        }

        boolean isValid = true;
        if (!adjList.containsKey(course1)) {
            adjList.put(course1, new ArrayList<>());
        }
        adjList.get(course1).add(course2);

        if (hasCycle(adjList)) {
            isValid = false;
        }

        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
            if (isValid) {
                writer.write("YES");
            } else {
                writer.write("NO");
            }
            writer.close();
        } catch (IOException e) {
            System.out.println("Error writing output file: " + e.getMessage());
        }
    }

    private static boolean hasCycle(Map<String, List<String>> adjList) {
        Set<String> visited = new HashSet<>();
        Set<String> recStack = new HashSet<>();

        for (String node : adjList.keySet()) {
            if (hasCycleUtil(node, adjList, visited, recStack)) {
                return true;
            }
        }
        return false;
    }

    private static boolean hasCycleUtil(String node, Map<String, List<String>> adjList, Set<String> visited, Set<String> recStack) {
        if (recStack.contains(node)) {
            return true;
        }
        if (visited.contains(node)) {
            return false;
        }
        visited.add(node);
        recStack.add(node);

        List<String> children = adjList.get(node);
        for (String child : children) {
            if (hasCycleUtil(child, adjList, visited, recStack)) {
                return true;
            }
        }

        recStack.remove(node);
        return false;
    }
}

        