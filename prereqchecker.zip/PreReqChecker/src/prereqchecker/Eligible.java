package prereqchecker;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;



/**
 * 
 * Steps to implement this class main method:
 * 
 * Step 1:
 * AdjListInputFile name is passed through the command line as args[0]
 * Read from AdjListInputFile with the format:
 * 1. a (int): number of courses in the graph
 * 2. a lines, each with 1 course ID
 * 3. b (int): number of edges in the graph
 * 4. b lines, each with a source ID
 * 
 * Step 2:
 * EligibleInputFile name is passed through the command line as args[1]
 * Read from EligibleInputFile with the format:
 * 1. c (int): Number of courses
 * 2. c lines, each with 1 course ID
 * 
 * Step 3:
 * EligibleOutputFile name is passed through the command line as args[2]
 * Output to EligibleOutputFile with the format:
 * 1. Some number of lines, each with one course ID
 */


 public class Eligible {
    public static void main(String[] args) {
        if (args.length < 3) {
            System.out.println("Execute: java -cp bin prereqchecker.Eligible <adjacency list INput file> <eligible INput file> <eligible OUTput file>");
            return;
        }

        String adjListFile = args[0];
        String eligibleFile = args[1];
        String outputFile = args[2];

        Map<String, Set<String>> graph = new HashMap<>();
        Set<String> takenCourses = new HashSet<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(adjListFile))) {
            int numCourses = Integer.parseInt(reader.readLine().trim());
            for (int i = 0; i < numCourses; i++) {
                graph.put(reader.readLine().trim(), new HashSet<>());
            }
            int numEdges = Integer.parseInt(reader.readLine().trim());
            for (int i = 0; i < numEdges; i++) {
                String[] edge = reader.readLine().trim().split(" ");
                graph.get(edge[0]).add(edge[1]);
            }
        } catch (IOException e) {
            System.out.println("Error reading adjacency list file: " + e.getMessage());
            return;
        }

        // Read eligible input
        try (BufferedReader reader = new BufferedReader(new FileReader(eligibleFile))) {
            int numTaken = Integer.parseInt(reader.readLine().trim());
            for (int i = 0; i < numTaken; i++) {
                takenCourses.add(reader.readLine().trim());
            }
        } catch (IOException e) {
            System.out.println("Error reading eligible input file: " + e.getMessage());
            return;
        }

        Set<String> effectivelyTaken = new HashSet<>(takenCourses);
        for (String course : takenCourses) {
            dfsMarkTaken(course, graph, effectivelyTaken);
        }

        Set<String> eligibleCourses = findEligibleCourses(graph, effectivelyTaken);


        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {
            for (String course : eligibleCourses) {
                writer.write(course);
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error writing output file: " + e.getMessage());
        }
    }

    private static void dfsMarkTaken(String course, Map<String, Set<String>> graph, Set<String> effectivelyTaken) {
        effectivelyTaken.add(course);
        for (String prereq : graph.get(course)) {
            if (!effectivelyTaken.contains(prereq)) {
                dfsMarkTaken(prereq, graph, effectivelyTaken);
            }
        }
    }

    private static Set<String> findEligibleCourses(Map<String, Set<String>> graph, Set<String> effectivelyTaken) {
        Set<String> eligibleCourses = new HashSet<>();
        for (String course : graph.keySet()) {
            if (!effectivelyTaken.contains(course) && areAllPrereqsTaken(course, graph, effectivelyTaken)) {
                eligibleCourses.add(course);
            }
        }
        return eligibleCourses;
    }

    private static boolean areAllPrereqsTaken(String course, Map<String, Set<String>> graph, Set<String> effectivelyTaken) {
        for (String prereq : graph.get(course)) {
            if (!effectivelyTaken.contains(prereq)) {
                return false;
            }
        }
        return true;
    }
}